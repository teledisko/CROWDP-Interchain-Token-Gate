var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/discord/callback/route.js")
R.c("server/chunks/[root-of-the-server]__a63110be._.js")
R.c("server/chunks/[root-of-the-server]__09c3bdaf._.js")
R.c("server/chunks/node_modules_next_8fda795c._.js")
R.m(33773)
R.m(41845)
module.exports=R.m(41845).exports
