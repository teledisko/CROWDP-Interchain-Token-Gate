var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/unlink/route.js")
R.c("server/chunks/[root-of-the-server]__2749f58d._.js")
R.c("server/chunks/node_modules_next_8fda795c._.js")
R.c("server/chunks/[root-of-the-server]__6abaad26._.js")
R.c("server/chunks/[root-of-the-server]__09c3bdaf._.js")
R.m(6127)
R.m(79343)
module.exports=R.m(79343).exports
