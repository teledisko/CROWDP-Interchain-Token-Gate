var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/roles/route.js")
R.c("server/chunks/[root-of-the-server]__02c7b97c._.js")
R.c("server/chunks/node_modules_next_8fda795c._.js")
R.c("server/chunks/[root-of-the-server]__6abaad26._.js")
R.c("server/chunks/[root-of-the-server]__09c3bdaf._.js")
R.m(82601)
R.m(36312)
module.exports=R.m(36312).exports
