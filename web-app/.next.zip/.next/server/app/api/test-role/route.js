var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/test-role/route.js")
R.c("server/chunks/[root-of-the-server]__2e74c78a._.js")
R.c("server/chunks/node_modules_next_8fda795c._.js")
R.c("server/chunks/src_app_lib_validation_ts_0b918766._.js")
R.c("server/chunks/[root-of-the-server]__6abaad26._.js")
R.c("server/chunks/[root-of-the-server]__09c3bdaf._.js")
R.m(93419)
R.m(23863)
module.exports=R.m(23863).exports
