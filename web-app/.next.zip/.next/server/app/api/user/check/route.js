var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/user/check/route.js")
R.c("server/chunks/[root-of-the-server]__9f999391._.js")
R.c("server/chunks/node_modules_next_8fda795c._.js")
R.c("server/chunks/[root-of-the-server]__6abaad26._.js")
R.c("server/chunks/src_app_lib_validation_ts_0b918766._.js")
R.c("server/chunks/[root-of-the-server]__09c3bdaf._.js")
R.m(20672)
R.m(87831)
module.exports=R.m(87831).exports
