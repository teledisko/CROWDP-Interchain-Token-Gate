globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/80e4490735f7773b.js",
      "static/chunks/turbopack-82b7b36e85294731.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/80e4490735f7773b.js",
      "static/chunks/turbopack-4504d6c48efd32d9.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/a72ef6269a3c6224.js",
    "static/chunks/522518d740397639.js",
    "static/chunks/2008ffcf9e5b170c.js",
    "static/chunks/6c1d949039ca8e4a.js",
    "static/chunks/turbopack-1ba7c63886c97bd9.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];