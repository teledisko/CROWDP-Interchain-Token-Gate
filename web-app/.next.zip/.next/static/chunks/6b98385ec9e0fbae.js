__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/80e4490735f7773b.js",
  "static/chunks/turbopack-82b7b36e85294731.js"
])
