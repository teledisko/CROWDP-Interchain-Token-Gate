__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/80e4490735f7773b.js",
  "static/chunks/turbopack-4504d6c48efd32d9.js"
])
